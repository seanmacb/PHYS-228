function [out] = squareman(inp)
out = inp.*inp;
end

