function [func] = quart(x)
func = x.^4+x-2;
end

