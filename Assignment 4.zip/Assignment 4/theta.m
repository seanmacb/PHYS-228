function [angle] = theta(s,L)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
angle = s/L;
end

